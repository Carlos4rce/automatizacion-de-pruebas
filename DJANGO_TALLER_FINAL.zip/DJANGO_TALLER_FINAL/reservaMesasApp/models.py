from django.db import models

class Reserva(models.Model):
    cliente   = models.CharField(max_length=30)
    fono      = models.CharField(max_length=20)
    fecha     = models.DateField()
    hora      = models.TimeField()
    cantidad  = models.IntegerField()
    ubicacion    = models.CharField(max_length=15)
    banda = models.CharField(max_length=100)
