from django.test import TestCase
from django.contrib.auth.models import User
from reservaMesasApp.models import Reserva

class PruebasReserva(TestCase):
    def setUp(self):
        # Configuración inicial para las pruebas
        self.superuser = User.objects.create_superuser(username='admin', password='adminpassword')
        self.client.login(username='admin', password='adminpassword')

    def test_agregar_reserva_exitosa(self):
        # Prueba para agregar una nueva reserva exitosamente
        response = self.client.post('/agregarReserva/', {'campo1': 'valor1', 'campo2': 'valor2'})
        self.assertEqual(response.status_code, 302)  # Debería redirigir después de agregar

        # Verificar que la reserva se haya agregado a la base de datos
        nueva_reserva = Reserva.objects.last()
        self.assertEqual(nueva_reserva.campo1, 'valor1')
        self.assertEqual(nueva_reserva.campo2, 'valor2')

    def test_iniciar_sesion_fallida(self):
        # Prueba para iniciar sesión fallida como usuario no autorizado
        response = self.client.post('/', {'username': 'usuario', 'password': 'contraseña'})
        self.assertEqual(response.status_code, 200)  # Debería permanecer en la página de inicio de sesión
        self.assertContains(response, 'Credenciales no válidas')  # Verificar mensaje de error en la respuesta