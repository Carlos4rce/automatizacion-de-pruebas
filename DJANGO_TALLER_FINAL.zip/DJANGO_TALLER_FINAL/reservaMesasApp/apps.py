from django.apps import AppConfig


class ReservamesasappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'reservaMesasApp'
