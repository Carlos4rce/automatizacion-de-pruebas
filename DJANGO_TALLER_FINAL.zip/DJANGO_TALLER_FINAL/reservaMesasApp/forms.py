from socket import fromshare
from django import forms
from reservaMesasApp.models import Reserva

UBICACION = [('canchageneral','Cancha General'),
        ('canchavip','Cancha VIP'),
        ('galeria','Galeria'),
        ('pacificocentro','Pacifico Centro')]

BANDA = [('metallica','Metallica'),
        ('ac/dc','AC/DC'),
        ('radiohead','Radiohead'),
        ('gunsnroses',"Guns N'Roses")]

class FormularioReservas(forms.ModelForm):
    class Meta:
        model = Reserva
        fields = '__all__'

    ubicacion = forms.CharField(widget=forms.Select(choices=UBICACION))
    banda = forms.CharField(widget=forms.Select(choices=BANDA))
    fecha = forms.DateField(widget=forms.widgets.DateInput(
            attrs={
                'type': 'date', 'placeholder': 'yyyy-mm-dd (DOB)',
                'class': 'form-control'
                }))


